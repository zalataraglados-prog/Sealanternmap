﻿-- Sealantermap Bridge (SeaLantern plugin)
-- One package with two responsibilities:
-- 1) Install/update Sealantermap core jar into selected Minecraft server plugins folder.
-- 2) Provide an in-app map preview modal inside SeaLantern.

local ROOT_ID = "sealantermap-bridge-root"
local STYLE_ID = "sealantermap-bridge-style"

local PREVIEW_URL = "http://127.0.0.1:8156/"
local PAYLOAD_RELATIVE_PATH = "payload/sealantermap-0.1.0.jar"
local PAYLOAD_FILE_NAME = "sealantermap-0.1.0.jar"

local function js_escape(value)
  local s = tostring(value or "")
  s = s:gsub("\\", "\\\\")
  s = s:gsub("\"", "\\\"")
  s = s:gsub("\r", "\\r")
  s = s:gsub("\n", "\\n")
  s = s:gsub("</", "<\\/")
  return s
end

local function fill_template(template, vars)
  local out = template
  for key, value in pairs(vars) do
    out = out:gsub("__" .. key .. "__", function()
      return value
    end)
  end
  return out
end

local function collect_servers_js()
  local ok, list = pcall(function()
    return sl.server.list()
  end)

  if not ok or type(list) ~= "table" then
    return "[]", 0
  end

  local rows = {}
  local count = 0
  for _, server in ipairs(list) do
    if server and server.id then
      local id = js_escape(server.id)
      local name = js_escape(server.name or server.id)
      rows[#rows + 1] = string.format("{id:\"%s\",name:\"%s\"}", id, name)
      count = count + 1
    end
  end

  return "[" .. table.concat(rows, ",") .. "]", count
end

local function load_payload_base64()
  if not sl.fs.exists(PAYLOAD_RELATIVE_PATH) then
    return nil, "核心载荷缺失: " .. PAYLOAD_RELATIVE_PATH
  end

  local ok, payload = pcall(function()
    return sl.fs.read_binary(PAYLOAD_RELATIVE_PATH)
  end)

  if not ok or type(payload) ~= "string" or payload == "" then
    return nil, "读取核心载荷失败"
  end

  return payload, nil
end

local function build_css()
  return [[
#slm-global-fab {
  position: fixed;
  right: 24px;
  bottom: 24px;
  z-index: 9100;
  padding: 10px 14px;
  border-radius: 10px;
  border: 1px solid var(--sl-primary-dark, #0369a1);
  background: var(--sl-primary, #0ea5e9);
  color: var(--sl-text-inverse, #ffffff);
  box-shadow: 0 10px 24px rgba(14, 165, 233, 0.28);
  cursor: pointer;
  font-size: 14px;
  font-weight: 600;
}

#slm-large-modal {
  position: fixed;
  inset: 0;
  z-index: 99999;
  background: rgba(2, 6, 23, 0.62);
  display: none;
  align-items: center;
  justify-content: center;
  padding: 24px;
}

.slm-modal-content {
  width: 100%;
  height: 100%;
  background: #0b1220;
  border: 1px solid rgba(148, 163, 184, 0.25);
  border-radius: 14px;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.slm-modal-header {
  height: 52px;
  padding: 8px 12px;
  background: #111827;
  border-bottom: 1px solid rgba(148, 163, 184, 0.2);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
}

.slm-title {
  display: flex;
  align-items: center;
  gap: 10px;
  color: #e2e8f0;
  font-weight: 700;
}

.slm-tools {
  display: flex;
  align-items: center;
  gap: 8px;
}

.slm-tools select,
.slm-tools button,
.slm-tools a {
  height: 30px;
  border-radius: 6px;
  border: 1px solid rgba(148, 163, 184, 0.3);
  background: rgba(30, 41, 59, 0.95);
  color: #e2e8f0;
  padding: 0 10px;
  font-size: 12px;
  display: inline-flex;
  align-items: center;
  text-decoration: none;
}

.slm-tools button { cursor: pointer; }
.slm-tools button:hover { background: rgba(51, 65, 85, 0.95); }

#slm-status {
  max-width: 240px;
  font-size: 12px;
  color: #94a3b8;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

#slm-status.err { color: #fca5a5; }

#slm-close {
  width: 30px;
  height: 30px;
  border: none;
  border-radius: 6px;
  background: rgba(255,255,255,0.1);
  color: #e2e8f0;
  cursor: pointer;
}

#slm-close:hover { background: rgba(239, 68, 68, 0.85); }

.slm-modal-body {
  flex: 1;
  position: relative;
  background: #000;
}

#slm-frame {
  width: 100%;
  height: 100%;
  border: none;
  background: #fff;
}

#slm-frame-mask {
  position: absolute;
  inset: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 24px;
  color: #cbd5e1;
  background: rgba(2, 6, 23, 0.65);
  font-size: 14px;
  line-height: 1.7;
}
]]
end

local function build_html(servers_js, payload_b64, payload_error)
  local template = [[
<div id="slm-bridge">
  <button id="slm-global-fab" title="打开地图预览">地图</button>

  <div id="slm-large-modal">
    <div class="slm-modal-content">
      <div class="slm-modal-header">
        <div class="slm-title">Sealantermap 地图预览</div>

        <div class="slm-tools">
          <select id="slm-server"></select>
          <button id="slm-check">检查核心</button>
          <button id="slm-install">安装核心</button>
          <a id="slm-open-browser" href="__PREVIEW_URL__" target="_blank" rel="noopener noreferrer">浏览器打开</a>
          <span id="slm-status" title="__PAYLOAD_ERROR__"></span>
        </div>

        <button id="slm-close" title="关闭">×</button>
      </div>

      <div class="slm-modal-body">
        <iframe id="slm-frame" src="about:blank"></iframe>
        <div id="slm-frame-mask">点击右上角“地图”进入预览。</div>
      </div>
    </div>
  </div>
</div>

<script>
(function() {
  if (window.__SLM_BRIDGE_MOUNTED__) return;
  window.__SLM_BRIDGE_MOUNTED__ = true;

  const PREVIEW_URL = "__PREVIEW_URL__";
  const SERVERS = __SERVERS__;
  const PAYLOAD_BASE64 = "__PAYLOAD_BASE64__";
  const PAYLOAD_ERROR = "__PAYLOAD_ERROR__";
  const JAR_FILE_NAME = "__JAR_FILE_NAME__";

  const openBtn = document.getElementById("slm-global-fab");
  const modal = document.getElementById("slm-large-modal");
  const closeBtn = document.getElementById("slm-close");
  const frame = document.getElementById("slm-frame");
  const frameMask = document.getElementById("slm-frame-mask");
  const serverSel = document.getElementById("slm-server");
  const statusEl = document.getElementById("slm-status");
  const checkBtn = document.getElementById("slm-check");
  const installBtn = document.getElementById("slm-install");

  let watchdogTimer = 0;
  let payloadBytes = null;

  function setStatus(text, isError) {
    statusEl.textContent = text || "";
    statusEl.classList.toggle("err", !!isError);
  }

  function setMask(text) {
    frameMask.textContent = text || "";
    frameMask.style.display = "flex";
  }

  function hideMask() {
    frameMask.style.display = "none";
  }

  function getInvoke() {
    if (window.__TAURI__ && window.__TAURI__.core && typeof window.__TAURI__.core.invoke === "function") {
      return window.__TAURI__.core.invoke;
    }
    if (window.__TAURI_INTERNALS__ && typeof window.__TAURI_INTERNALS__.invoke === "function") {
      return window.__TAURI_INTERNALS__.invoke;
    }
    return null;
  }

  const invoke = getInvoke();

  function decodeBase64(base64) {
    const bin = atob(base64);
    const out = new Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  function getPayloadBytes() {
    if (!payloadBytes) payloadBytes = decodeBase64(PAYLOAD_BASE64);
    return payloadBytes;
  }

  function fillServerSelect() {
    serverSel.innerHTML = "";
    for (const s of SERVERS) {
      const opt = document.createElement("option");
      opt.value = s.id;
      opt.textContent = s.name + " (" + s.id + ")";
      serverSel.appendChild(opt);
    }

    if (!SERVERS.length) {
      const opt = document.createElement("option");
      opt.value = "";
      opt.textContent = "未发现服务器";
      serverSel.appendChild(opt);
      serverSel.disabled = true;
      checkBtn.disabled = true;
      installBtn.disabled = true;
    }
  }

  function selectedServerId() {
    return serverSel.value || "";
  }

  async function checkInstallState() {
    if (!invoke) return setStatus("Tauri 调用不可用", true);
    const sid = selectedServerId();
    if (!sid) return setStatus("请先选择服务器", true);

    try {
      setStatus("检查中...", false);
      const list = await invoke("m_get_plugins", { serverId: sid });
      const found = Array.isArray(list) && list.some((p) => {
        const fileName = String((p && p.file_name) || "").toLowerCase();
        const pluginName = String((p && p.name) || "").toLowerCase();
        return fileName === JAR_FILE_NAME.toLowerCase() || pluginName.includes("sealantermap");
      });
      setStatus(found ? "核心已安装" : "核心未安装", false);
    } catch (_e) {
      setStatus("检查失败", true);
    }
  }

  async function installCore() {
    if (!invoke) return setStatus("Tauri 调用不可用", true);
    const sid = selectedServerId();
    if (!sid) return setStatus("请先选择服务器", true);
    if (!PAYLOAD_BASE64) return setStatus("核心载荷不可用", true);

    checkBtn.disabled = true;
    installBtn.disabled = true;
    try {
      setStatus("安装中...", false);
      await invoke("m_install_plugin", {
        serverId: sid,
        fileData: getPayloadBytes(),
        fileName: JAR_FILE_NAME
      });
      setStatus("安装完成，请重启对应游戏服", false);
      await checkInstallState();
    } catch (_e) {
      setStatus("安装失败", true);
    } finally {
      checkBtn.disabled = false;
      installBtn.disabled = false;
    }
  }

  function clearWatchdog() {
    if (watchdogTimer) {
      clearTimeout(watchdogTimer);
      watchdogTimer = 0;
    }
  }

  function armWatchdog() {
    clearWatchdog();
    watchdogTimer = setTimeout(() => {
      setMask("地图服务无响应。\n请确认游戏服已安装并启动 Sealantermap 核心插件，\n且 127.0.0.1:8156 可访问。\n也可点击“浏览器打开”排查。\n");
    }, 8000);
  }

  function openModal() {
    modal.style.display = "flex";
    setMask("正在连接地图服务...");
    armWatchdog();
    const join = PREVIEW_URL.includes("?") ? "&" : "?";
    frame.src = PREVIEW_URL + join + "t=" + Date.now();
  }

  function closeModal() {
    modal.style.display = "none";
    clearWatchdog();
    frame.src = "about:blank";
    setMask("点击右上角“地图”进入预览。");
  }

  async function preflight() {
    try {
      const res = await fetch(PREVIEW_URL + "stats.json?t=" + Date.now(), { cache: "no-store" });
      if (res.ok) {
        setStatus("地图服务在线", false);
      } else {
        setStatus("地图服务返回异常: HTTP " + res.status, true);
      }
    } catch (_e) {
      setStatus("地图服务不可达", true);
    }
  }

  frame.addEventListener("load", function() {
    clearWatchdog();
    hideMask();
  });

  frame.addEventListener("error", function() {
    clearWatchdog();
    setMask("地图加载失败。可先尝试“浏览器打开”，再检查服务日志。");
  });

  openBtn.addEventListener("click", openModal);
  closeBtn.addEventListener("click", closeModal);
  checkBtn.addEventListener("click", checkInstallState);
  installBtn.addEventListener("click", installCore);

  window.addEventListener("keydown", function(e) {
    if (e.key === "Escape" && modal.style.display !== "none") {
      closeModal();
    }
  });

  fillServerSelect();
  if (PAYLOAD_BASE64) {
    setStatus("就绪", false);
  } else {
    setStatus(PAYLOAD_ERROR || "核心载荷不可用", true);
  }
  preflight();
})();
</script>
]]

  return fill_template(template, {
    PREVIEW_URL = js_escape(PREVIEW_URL),
    SERVERS = servers_js,
    PAYLOAD_BASE64 = js_escape(payload_b64 or ""),
    PAYLOAD_ERROR = js_escape(payload_error or ""),
    JAR_FILE_NAME = js_escape(PAYLOAD_FILE_NAME)
  })
end

local function mount_ui()
  local servers_js, server_count = collect_servers_js()
  local payload_b64, payload_error = load_payload_base64()

  sl.ui.inject_css(STYLE_ID, build_css())
  sl.ui.inject_html(ROOT_ID, build_html(servers_js, payload_b64, payload_error))

  sl.log.info("[SealantermapBridge] UI mounted, servers=" .. tostring(server_count))
  if payload_error then
    sl.log.warn("[SealantermapBridge] payload error: " .. payload_error)
  end
end

local function unmount_ui()
  sl.ui.remove_html(ROOT_ID)
  sl.ui.remove_css(STYLE_ID)
end

function onLoad()
  sl.log.info("[SealantermapBridge] loaded")
end

function onEnable()
  mount_ui()
  sl.log.info("[SealantermapBridge] enabled")
end

function onDisable()
  unmount_ui()
  sl.log.info("[SealantermapBridge] disabled")
end

function onUnload()
  unmount_ui()
  sl.log.info("[SealantermapBridge] unloaded")
end
